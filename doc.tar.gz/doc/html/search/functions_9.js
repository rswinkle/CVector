var searchData=
[
  ['template_5ftest',['template_test',['../main_8c.html#a53b765d3e172badc70fec0cd5bf41565',1,'template_test():&#160;vector_tests.c'],['../vector__tests_8c.html#a53b765d3e172badc70fec0cd5bf41565',1,'template_test():&#160;vector_tests.c']]],
  ['template_5ftest2',['template_test2',['../main_8c.html#a280802dcfe1e667e29b193626afe2a3b',1,'template_test2():&#160;vector_tests.c'],['../vector__tests_8c.html#a280802dcfe1e667e29b193626afe2a3b',1,'template_test2():&#160;vector_tests.c']]]
];
