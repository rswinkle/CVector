var searchData=
[
  ['elem_5ffree',['elem_free',['../structvector__void.html#abed2ac06e76256419b825b31e879b204',1,'vector_void::elem_free()'],['../structvector__f__struct.html#a5464311934fa85ead14cdfe90b9efdc0',1,'vector_f_struct::elem_free()'],['../structvector___t_y_p_e.html#a0ebd337f312279fe2fb82e7a879f6456',1,'vector_TYPE::elem_free()']]],
  ['elem_5finit',['elem_init',['../structvector__void.html#af5d27d7e1af89d5dfbcf49f1810cc0c2',1,'vector_void::elem_init()'],['../structvector__f__struct.html#a6a837da0e16a7159c7c1801b4a52d406',1,'vector_f_struct::elem_init()'],['../structvector___t_y_p_e.html#acc422333d8ea0e69a98f9016019a7b09',1,'vector_TYPE::elem_init()']]],
  ['elem_5fsize',['elem_size',['../structvector__void.html#afedda26ce85492462b79dae9090c49f6',1,'vector_void']]]
];
