var searchData=
[
  ['back_5ff_5fstruct',['back_f_struct',['../vector__f__struct_8h.html#a464b755eb62313d41d0e768f29753dad',1,'vector_f_struct.h']]],
  ['back_5fshort',['back_short',['../vector__short_8h.html#a4a7032ff983b4f3e0a0a132775727fe2',1,'vector_short.h']]],
  ['back_5ftype',['back_TYPE',['../vector__template_8h.html#aa9bf889e6f2992f2b2eb3997e7989aa9',1,'back_TYPE(vector_TYPE *vec):&#160;vector_template3.c'],['../vector__template2_8h.html#aa9bf889e6f2992f2b2eb3997e7989aa9',1,'back_TYPE(vector_TYPE *vec):&#160;vector_template3.c'],['../vector__template3_8c.html#aa9bf889e6f2992f2b2eb3997e7989aa9',1,'back_TYPE(vector_TYPE *vec):&#160;vector_template3.c'],['../vector__template3_8h.html#aa9bf889e6f2992f2b2eb3997e7989aa9',1,'back_TYPE(vector_TYPE *vec):&#160;vector_template3.c'],['../vector__template4_8c.html#aa9bf889e6f2992f2b2eb3997e7989aa9',1,'back_TYPE(vector_TYPE *vec):&#160;vector_template4.c'],['../vector__template4_8h.html#aa9bf889e6f2992f2b2eb3997e7989aa9',1,'back_TYPE(vector_TYPE *vec):&#160;vector_template3.c']]]
];
